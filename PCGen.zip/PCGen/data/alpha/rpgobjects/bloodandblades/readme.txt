I found out too late that Paul King had already coded some of this source, so I ended up using only a bit of his files in the classes.
Paul also did the .NAM file (do we use these?), the rest is what I came up with.

Here are the issues that I found within the source. I have already reported these to Paul K., in case he wants to give RPGO feedback.


The Tough Guy victim class is getting a choice of Improved Unarmed Strike or Improved Grapple. Improved Unarmed Strike doesn't
	exist by that name in Modern, it is essentially the Brawl feat and I have used that one in the class.

The Arawnite Guardian advanced class has Heal as a class skill. The modern skill is called Treat Injury, which I used instead.
	Also Knowledge (Nature) doesn't exist, the modern skill is called Knowledge (Earth and Life Sciences) and I have used that.
	Lvl. 1 Spell 'Pass without Trace' does not exist

The Stalker class has 3 bonus feats listed, that do not exist anywhere: Stalker, Insane Speed and Insane Strength.

The Pumpkin Demon has the Head Squish slasher feat. Prerequisites for that are Brawl and Improved Grapple, which the Pumpkin Demon lacks.
	The Intimidate skill is +17, with +2 from CHA that means 15 skill ranks, which exceeds the maximum of 13.
	Available Skill Points 100 (8 +2 INT bonus = 10;10 HD, first level not x4)
	Used Skill Points 136

The Slasher Demon: The Hide Skill is +20, with +4 from DEX and +8 from Size that means 8 skill ranks, which exceeds the maximum of 4.
	Available Skill Points 7 (8 -1 INT penalty =7, 1HD, first level not x4)
	Used Skill Points	16
	Bite attack is -1, should be -2 (+1 BAB, +2 Size, -5 STR)

Dream Stalker: Feat Combat Casting does not exist in Modern.
	Available Skill Points 64 (8 no INT bonus, 8HD, first level not x4)
	Used Skill Points 92

Lurker: has 11 skill points left

Sentinel Sphere: CR is missing.

Thin Stranger: Drive +8 should be +7 (+8 would exceed max. Skillrank and spend 1 skill point too many)

-- Frank