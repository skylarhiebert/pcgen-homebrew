- Schools can be acquired at any time if the prerequisites are met. I made them COST:0 feats and not templates, because	it
	should be easier to convert them to abilities once we have that.

- '2nd Degree Mastery - Deft Touch' should grant (INT bonus) additional creature type selections for the feats Stunning Fist,
	Nauseating Punch and Blinding Punch, but those feats do not have any creature type selection in their desciption - probably
	an editing error.

- This Source does not include values for SPELLFAILURE for shields. The Rochin is said to follow the rules for the small shield,
	so I took SPELLFAILURE from MSRD Arcana, but the Bomb Shield does not have SPELLFAILURE.

- This Source also includes the shields from MSRD Arcana. I have loaded those from that source, as the data is exactly the same.

-- Frank Kliewe, 2006/02/20