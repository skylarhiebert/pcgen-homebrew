# CVS $Revision: 1.1 $ $Author: eddyanthony $
The "secondary discipline" concept from the ITCK Psion variant is unsupported by PCGen 
and so is not included.

The "spells as powers" list is not included: partially because PCGen doesn't like 
two spells with the same name, but mainly because I feel personally that DMs should 
approve each spell on its own rather than import them in bulk.

Also, the Colorless Adept prestige class is not granting Power Points; this seems to
be because PCGen isn't picking up the added spellcaster levels when making the PP
calculation.

#------------------
04/24/2005 - TaluronIscandar

3.0 notes:
Brought all 3.0 files up to ITCK third update.
Brought all 3.0 files up to new SRD psionics standard. SRD Psionics has been reworked to allow PrC levels 
to stack.

Corrected typo in SOURCELONG (Thoughts not Thought)

Secondary discipline DC supported by hidden feats.

Colorless Adept should grant power points now due to srd psionics update.

3.5 notes:
Added files for 3.5 update.
