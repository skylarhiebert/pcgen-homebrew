No real issues with this one. :-)

I have coded the Damage Reduction Conversion and the Armor Penetration as EQMODs. 
This will allow the user to set up pieces of armor and weapons according to these 
rules, that were not included in the PDF and thus use the offered system universally 
(as the PDF suggests to do).

-- Frank Kliewe, 2006-01-20
