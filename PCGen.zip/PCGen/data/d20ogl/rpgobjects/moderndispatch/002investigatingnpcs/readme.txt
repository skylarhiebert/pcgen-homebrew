Problem: CHOOSE:NUMBERS doesn't work in Feats, had to use a series of hidden Feats instead.

-- Frank, 2006.01.22