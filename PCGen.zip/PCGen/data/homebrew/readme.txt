Hi Folks, place your homebrew sets in this folder here in their own folders.

examples:
homebrew/cool_campaign
homebrew/dragon_book

etc.